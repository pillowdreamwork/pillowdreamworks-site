# Books: production-readiness pass (drop-in)

Copy `src/` over your repo at the same paths. Only /books files are touched.

## Changed in this pass
- BooksExperience.tsx: handleReturn now does setSelectedBookId(null) + scrollTo top (also clears pendingScroll)
- PurchaseControl.tsx: real checkout link uses target="_blank" rel="noopener noreferrer"; fallback unchanged
- data/books.ts: unverified image titles/captions made neutral (see below)
- BookDetails.tsx / PageStory.tsx: alt text and labels follow the neutral titles ("Page 2 of 5 from …")

## Neutral labels (confirm and replace once checked against the assets)
- FTC detail images (about, how-it-works, everyday-life, therapeutic-settings): "Selected page"
- FTC ftc-welcome: "Selected page"
- Toolkit pt-founder, pt-about, pt-thank-you: "Selected page"; pt-contents keeps "Table of Contents"
- Toolkit pt-ch1-lesson1/lesson5/worksheet: "From Chapter 1"

## Not changed
Prices, bundle contents, FAQ wording, StoryScene, single selectedBookId state.

## tests/behavior.test.tsx
jsdom behaviour test (run with `npx tsx`): both selection orders, bundle last, FAQ aria, checkout fallback,
return-to-library reset, re-selection. Optional; not part of the site.
