import { JSDOM } from "jsdom";
const dom = new JSDOM("<!doctype html><html><body><div id='root'></div></body></html>", { pretendToBeVisual: true, url: "http://localhost/books" });
const g = globalThis as any;
g.window = dom.window; g.document = dom.window.document; g.navigator = dom.window.navigator;
for (const k of ["HTMLElement","Element","Node","MutationObserver","getComputedStyle","SVGElement","HTMLImageElement","Event","MouseEvent","KeyboardEvent"]) g[k] = (dom.window as any)[k];
g.IS_REACT_ACT_ENVIRONMENT = true;
g.requestAnimationFrame = (cb: any) => setTimeout(() => cb(Date.now()), 0); g.cancelAnimationFrame = (id: any) => clearTimeout(id);
(dom.window as any).requestAnimationFrame = g.requestAnimationFrame;
let scrollCalls: any[] = [];
(dom.window as any).scrollTo = (o: any) => scrollCalls.push(o);
(dom.window as any).matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
g.matchMedia = (dom.window as any).matchMedia;
class IO { constructor(public cb: any) {} observe() {} unobserve() {} disconnect() {} takeRecords() { return []; } }
class RO extends IO {}
g.IntersectionObserver = (dom.window as any).IntersectionObserver = IO; g.ResizeObserver = (dom.window as any).ResizeObserver = RO;
(dom.window.HTMLElement.prototype as any).scrollIntoView = function () {};

import React, { act } from "react";
import { createRoot } from "react-dom/client";
import { BooksExperience } from "@/components/books/BooksExperience";

const assert = (c: any, m: string) => { if (!c) { console.error("FAIL:", m); process.exit(1); } console.log("pass:", m); };
const errors: any[] = []; const origErr = console.error; console.error = (...a: any[]) => { errors.push(a.join(" ")); };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function run(first: string, second: string) {
  const root = createRoot(document.getElementById("root")!);
  await act(async () => { root.render(<BooksExperience />); });
  const worlds = () => [...document.querySelectorAll("[id^='world-']")].map((e) => e.id);
  assert(worlds().length === 0, `[${first}] entrance only, no world mounted`);
  const btn = [...document.querySelectorAll("button")].find((b) => b.getAttribute("aria-label") === `Open ${first}`) as HTMLButtonElement;
  assert(!!btn, `[${first}] book button exists with aria-label`);
  await act(async () => { btn.click(); });
  await act(async () => { await sleep(900); });
  const w = worlds();
  assert(w.length === 2, `[${first}] both worlds mounted after one selection (${w.join(", ")})`);
  const firstId = first === "Finding The Centre" ? "world-finding-the-centre" : "world-psychology-toolkit";
  const secondId = firstId === "world-finding-the-centre" ? "world-psychology-toolkit" : "world-finding-the-centre";
  assert(w[0] === firstId && w[1] === secondId, `[${first}] order is ${first} then ${second}`);
  assert(!!document.querySelector("section[aria-label='The complete library']"), `[${first}] bundle appears after both books`);
  assert(document.body.textContent!.includes("₹1,799 / $29.99"), `[${first}] bundle price shown`);
  // FAQ: first question toggles aria-expanded
  const q = document.querySelector("button[aria-controls]") as HTMLButtonElement;
  assert(q.getAttribute("aria-expanded") === "false", `[${first}] FAQ starts collapsed`);
  await act(async () => { q.click(); });
  assert(q.getAttribute("aria-expanded") === "true" && !!document.getElementById(q.getAttribute("aria-controls")!), `[${first}] FAQ expands and panel id matches`);
  // Purchase fallback (no checkout URL)
  const buy = [...document.querySelectorAll("button")].find((b) => /^Buy /.test(b.textContent || "")) as HTMLButtonElement;
  await act(async () => { buy.click(); });
  assert(document.body.textContent!.includes("Checkout is being prepared"), `[${first}] honest checkout fallback shown`);
  // Return to library resets everything
  scrollCalls = [];
  const ret = [...document.querySelectorAll("button")].find((b) => b.textContent === "Return to the library") as HTMLButtonElement;
  await act(async () => { ret.click(); });
  assert(worlds().length === 0, `[${first}] return clears the selected book (no worlds)`);
  assert(!document.querySelector("section[aria-label='The complete library']"), `[${first}] bundle removed after return`);
  assert(scrollCalls.some((c) => c && c.top === 0), `[${first}] scrolled to top`);
  // Can choose the OTHER book afterwards
  const other = [...document.querySelectorAll("button")].find((b) => b.getAttribute("aria-label") === `Open ${second}`) as HTMLButtonElement;
  await act(async () => { other.click(); });
  await act(async () => { await sleep(900); });
  assert(worlds()[0] === secondId.replace("world-", "world-") && worlds().length === 2, `[${second}] reselect works after return`);
  await act(async () => { root.unmount(); });
  document.body.innerHTML = "<div id='root'></div>";
}
(async () => {
  await run("Finding The Centre", "The Psychology Toolkit");
  await run("The Psychology Toolkit", "Finding The Centre");
  console.error = origErr;
  const real = errors.filter((e) => !/not wrapped in act|ReactDOMTestUtils|useLayoutEffect/.test(e));
  console.log("console errors:", real.length ? real.slice(0, 5) : "none");
  console.log("ALL BEHAVIOUR TESTS PASSED");
  process.exit(0);
})();
