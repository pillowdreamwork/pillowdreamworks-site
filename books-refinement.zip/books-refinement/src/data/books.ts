export interface BookFormat {
  id: string;
  type: string;
  priceINR: number;
  priceUSD: number;
  /** Only wording that follows directly from the format itself. */
  description?: string;
  /** Set only when an approved checkout destination exists. */
  checkoutUrl?: string;
}

export interface BookChapter {
  id: string;
  /** "01", "02" … or a word such as "Resources" for the closing section. */
  label: string;
  numbered: boolean;
  title: string;
  subtitle?: string;
  pages?: string;
  image?: string;
  imageAlt?: string;
  keyContents?: string[];
}

export interface BookScrollItem {
  src: string;
  /** Neutral label derived from the asset, never invented copy. */
  caption: string;
}

export interface BookFact {
  label: string;
  value: string;
}

export interface BookFaq {
  question: string;
  answer: string;
}

export interface Book {
  id: string;
  title: string;
  subtitle: string;
  author: string;
  description: string;
  cover: string;
  coverSecondary?: string;
  /** Text printed on the cover, reproduced verbatim. */
  coverText?: string[];
  pricing: {
    currency: 'INR' | 'USD';
    formats: BookFormat[];
  };
  scrollJourney: BookScrollItem[];
  chapters: BookChapter[];
  detailsImages: { title: string; src: string }[];
  facts: BookFact[];
  faqs: BookFaq[];
  personality: 'toolkit' | 'centre';
}

export const BOOKS: Book[] = [
  {
    id: 'finding-the-centre',
    title: 'Finding The Centre',
    subtitle: 'A Therapeutic Coloring & Reflection Workbook',
    author: 'Manish Garg',
    description:
      'A gentle guide to a calmer, kinder you. Combining beautiful illustrations with reflective prompts to encourage emotional wellbeing.',
    cover: '/images/books/finding-centre/ftc-cover-color.jpg',
    coverSecondary: '/images/books/finding-centre/ftc-cover-cream.jpg',
    coverText: [
      'for Children, Teens & Adults',
      '10 Themes for Mindfulness, Emotional Wellbeing & Self-Reflection',
    ],
    pricing: {
      currency: 'INR',
      formats: [
        { id: 'ebook', type: 'eBook', priceINR: 749, priceUSD: 12.49, description: 'Digital edition.' },
        { id: 'paperback', type: 'Paperback', priceINR: 1499, priceUSD: 24.99, description: 'Printed edition.' },
      ],
    },
    scrollJourney: [
      { src: '/images/books/finding-centre/ftc-cover-color.jpg', caption: 'Cover' },
      { src: '/images/books/finding-centre/ftc-welcome.jpg', caption: 'Selected page' },
      { src: '/images/books/finding-centre/ftc-safe-heart.jpg', caption: 'The Safe Heart' },
      { src: '/images/books/finding-centre/ftc-home-inside.jpg', caption: 'Home Inside Me' },
      { src: '/images/books/finding-centre/ftc-core-contour.jpg', caption: 'The Core and the Contour' },
    ],
    chapters: [
      { id: 'ftc-1', label: '01', numbered: true, title: 'The Safe Heart', image: '/images/books/finding-centre/ftc-safe-heart.jpg', imageAlt: 'Page from Finding The Centre: The Safe Heart' },
      { id: 'ftc-2', label: '02', numbered: true, title: 'Home Inside Me', image: '/images/books/finding-centre/ftc-home-inside.jpg', imageAlt: 'Page from Finding The Centre: Home Inside Me' },
      { id: 'ftc-3', label: '03', numbered: true, title: 'The Core and the Contour', image: '/images/books/finding-centre/ftc-core-contour.jpg', imageAlt: 'Page from Finding The Centre: The Core and the Contour' },
    ],
    detailsImages: [
      // Titles are neutral until each page is confirmed against its asset.
      { title: 'Selected page', src: '/images/books/finding-centre/ftc-about.jpg' },
      { title: 'Selected page', src: '/images/books/finding-centre/ftc-how-it-works.jpg' },
      { title: 'Selected page', src: '/images/books/finding-centre/ftc-everyday-life.jpg' },
      { title: 'Selected page', src: '/images/books/finding-centre/ftc-therapeutic-settings.jpg' },
    ],
    facts: [
      { label: 'Author', value: 'Manish Garg' },
      { label: 'Editions', value: 'eBook · Paperback' },
      { label: 'On the cover', value: 'for Children, Teens & Adults — 10 Themes for Mindfulness, Emotional Wellbeing & Self-Reflection' },
    ],
    faqs: [
      {
        question: 'Who is Finding The Centre for?',
        answer:
          'The book is presented for Children, Teens & Adults. It is designed as a coloring and reflection workbook for personal exploration and emotional wellbeing.',
      },
      {
        question: 'Do I need artistic experience?',
        answer:
          'No particular artistic experience is presented as a requirement. The workbook combines coloring with reflection, allowing the reader to engage with the pages at their own pace.',
      },
      {
        question: 'Can this replace professional therapy?',
        answer:
          'No. This book is a supportive, creative resource. It is not intended to replace professional psychological assessment, diagnosis, or treatment.',
      },
      {
        question: 'Which editions are available?',
        answer: 'Finding The Centre is available as an eBook and as a Paperback.',
      },
    ],
    personality: 'centre',
  },
  {
    id: 'psychology-toolkit',
    title: 'The Psychology Toolkit',
    subtitle: 'Book 1: The Psychology Playbook',
    author: 'Manish Garg',
    description:
      'Practical tools for emotional wellbeing. Bringing together psychology, habits, and mindfulness for everyday resilience.',
    cover: '/images/books/psychology-toolkit/pt-cover.jpg',
    pricing: {
      currency: 'INR',
      formats: [
        { id: 'digital', type: 'Digital PDF', priceINR: 1499, priceUSD: 24.99, description: 'Delivered as a digital PDF.' },
      ],
    },
    scrollJourney: [
      { src: '/images/books/psychology-toolkit/pt-cover.jpg', caption: 'Cover' },
      { src: '/images/books/psychology-toolkit/pt-ch1-opener.jpg', caption: 'Chapter 1 · Opener' },
      { src: '/images/books/psychology-toolkit/pt-ch1-lesson1.jpg', caption: 'From Chapter 1' },
      { src: '/images/books/psychology-toolkit/pt-ch1-lesson5.jpg', caption: 'From Chapter 1' },
      { src: '/images/books/psychology-toolkit/pt-ch1-worksheet.jpg', caption: 'From Chapter 1' },
    ],
    chapters: [
      {
        id: 'pt-1', label: '01', numbered: true,
        title: 'Understanding Your Mind',
        subtitle: 'Emotions, self-awareness & emotional regulation',
        pages: '6–20',
        image: '/images/books/psychology-toolkit/pt-ch1-opener.jpg',
        imageAlt: 'Chapter 1 opener page from The Psychology Toolkit',
        keyContents: ['Chapter Opener', 'What Is Psychology?', 'The Brain & Behaviour', 'Understanding Emotions', 'Why We Feel Emotions', 'Triggers • Exercises • Review'],
      },
      {
        id: 'pt-2', label: '02', numbered: true,
        title: 'Thoughts & Mindset',
        subtitle: 'Recognising thinking patterns & building resilience',
        pages: '21–35',
        keyContents: ['Chapter Opener', 'Understanding Thoughts', 'Cognitive Distortions', 'Reframing Your Thoughts', 'Exercises • Reflection • Summary'],
      },
      {
        id: 'pt-3', label: '03', numbered: true,
        title: 'Anxiety & Stress',
        subtitle: 'Practical tools for emotional regulation',
        pages: '36–50',
        keyContents: ['Chapter Opener', 'Understanding Anxiety', 'The Stress Response', 'Calming Your Nervous System', 'Coping Strategies', 'Worksheets • Tools • Review'],
      },
      {
        id: 'pt-4', label: '04', numbered: true,
        title: 'Relationships & Boundaries',
        subtitle: 'Building healthier connections',
        pages: '51–65',
        keyContents: ['Chapter Opener', 'Healthy vs Unhealthy Relationships', 'Setting & Maintaining Boundaries', 'Communication Skills', 'Self-Respect & Saying No', 'Exercises • Support Map • Review'],
      },
      {
        id: 'pt-5', label: '05', numbered: true,
        title: 'Habits & Personal Growth',
        subtitle: 'Turning awareness into daily action',
        pages: '66–75',
        keyContents: ['Chapter Opener', 'The Science of Habits', 'Building Positive Habits', 'Values & Goal Setting', 'Creating Your Routine', 'Habit Tracker • Exercises • Future You'],
      },
      {
        id: 'pt-6', label: 'Resources', numbered: false,
        title: 'Resources & Closing',
        subtitle: 'Continue your journey beyond this workbook',
        pages: '76–80',
        keyContents: ['Recommended Books & Resources', 'Psychology Tools Index', '30-Day Progress Review', 'Final Reflection & Commitment', 'Thank You • Foundation Resources'],
      },
    ],
    detailsImages: [
      // 'Table of Contents' is confirmed by the contents transcription; others stay neutral.
      { title: 'Selected page', src: '/images/books/psychology-toolkit/pt-founder.jpg' },
      { title: 'Table of Contents', src: '/images/books/psychology-toolkit/pt-contents.jpg' },
      { title: 'Selected page', src: '/images/books/psychology-toolkit/pt-about.jpg' },
      { title: 'Selected page', src: '/images/books/psychology-toolkit/pt-thank-you.jpg' },
    ],
    facts: [
      { label: 'Author', value: 'Manish Garg' },
      { label: 'Format', value: 'Digital PDF' },
      { label: 'Structure', value: 'Five chapters, followed by Resources & Closing' },
    ],
    faqs: [
      {
        question: 'What does the workbook cover?',
        answer:
          'Five chapters — Understanding Your Mind, Thoughts & Mindset, Anxiety & Stress, Relationships & Boundaries, and Habits & Personal Growth — followed by a Resources & Closing section.',
      },
      {
        question: 'Is this workbook a substitute for clinical diagnosis?',
        answer:
          'No. The Psychology Toolkit is designed for self-reflection and personal development. It does not provide clinical diagnoses or medical advice.',
      },
      {
        question: 'What format is the workbook delivered in?',
        answer: 'It is delivered as a digital PDF.',
      },
    ],
    personality: 'toolkit',
  },
];

export const BUNDLE_PRICING = {
  currency: 'INR' as const,
  bundlePriceINR: 1799,
  bundlePriceUSD: 29.99,
  includes: ['Finding The Centre eBook', 'The Psychology Toolkit Digital PDF'],
  summary: 'A shared digital collection bringing both works together.',
  /** Set only when an approved checkout destination exists. */
  checkoutUrl: undefined as string | undefined,
};

export const formatPrice = (priceINR: number, priceUSD: number): string =>
  `₹${priceINR.toLocaleString('en-IN')} / $${priceUSD.toFixed(2)}`;
